var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["1a849918-2af5-4018-9fbd-6e8762d888ad","efbba907-9402-43d9-aefd-0bde98033cbc","8572c91d-90e3-4bed-9d89-76786dbdb9fc","a91074cd-94af-4a21-b44f-b034c994624e","38d1ef9e-37b1-4c05-a212-3cf4e06dda65","b4878bf5-aba3-4063-9897-b7f4d917859f","1066a37c-88b6-4361-ab0d-0a5321f966fa"],"propsByKey":{"1a849918-2af5-4018-9fbd-6e8762d888ad":{"name":"space","sourceUrl":null,"frameSize":{"x":600,"y":721},"frameCount":1,"looping":true,"frameDelay":12,"version":"WPDjYhMhkCl3mdY952veZIULUbEqxZrP","loadedFromSource":true,"saved":true,"sourceSize":{"x":600,"y":721},"rootRelativePath":"assets/1a849918-2af5-4018-9fbd-6e8762d888ad.png"},"efbba907-9402-43d9-aefd-0bde98033cbc":{"name":"enemyBlack3_1","sourceUrl":"assets/api/v1/animation-library/gamelab/zCat2wSxi.yio2rKDxvF_eBKkhmF79Lu/category_vehicles/enemyBlack3.png","frameSize":{"x":103,"y":84},"frameCount":1,"looping":true,"frameDelay":2,"version":"zCat2wSxi.yio2rKDxvF_eBKkhmF79Lu","loadedFromSource":true,"saved":true,"sourceSize":{"x":103,"y":84},"rootRelativePath":"assets/api/v1/animation-library/gamelab/zCat2wSxi.yio2rKDxvF_eBKkhmF79Lu/category_vehicles/enemyBlack3.png"},"8572c91d-90e3-4bed-9d89-76786dbdb9fc":{"name":"enemyGreen3_1","sourceUrl":"assets/api/v1/animation-library/gamelab/MWC194esqFKe2M5MrwwqQV3usBbOoZpz/category_vehicles/enemyGreen3.png","frameSize":{"x":103,"y":84},"frameCount":1,"looping":true,"frameDelay":2,"version":"MWC194esqFKe2M5MrwwqQV3usBbOoZpz","loadedFromSource":true,"saved":true,"sourceSize":{"x":103,"y":84},"rootRelativePath":"assets/api/v1/animation-library/gamelab/MWC194esqFKe2M5MrwwqQV3usBbOoZpz/category_vehicles/enemyGreen3.png"},"a91074cd-94af-4a21-b44f-b034c994624e":{"name":"enemyRed3_1","sourceUrl":"assets/api/v1/animation-library/gamelab/0BG4zTuromoqnNoOBdLHPnUPcBxRwZ29/category_vehicles/enemyRed3.png","frameSize":{"x":103,"y":84},"frameCount":1,"looping":true,"frameDelay":2,"version":"0BG4zTuromoqnNoOBdLHPnUPcBxRwZ29","loadedFromSource":true,"saved":true,"sourceSize":{"x":103,"y":84},"rootRelativePath":"assets/api/v1/animation-library/gamelab/0BG4zTuromoqnNoOBdLHPnUPcBxRwZ29/category_vehicles/enemyRed3.png"},"38d1ef9e-37b1-4c05-a212-3cf4e06dda65":{"name":"enemyBlue3_1","sourceUrl":"assets/api/v1/animation-library/gamelab/Eiu.WuwvW39laembOazYF_zvNSHrKazn/category_vehicles/enemyBlue3.png","frameSize":{"x":103,"y":84},"frameCount":1,"looping":true,"frameDelay":2,"version":"Eiu.WuwvW39laembOazYF_zvNSHrKazn","loadedFromSource":true,"saved":true,"sourceSize":{"x":103,"y":84},"rootRelativePath":"assets/api/v1/animation-library/gamelab/Eiu.WuwvW39laembOazYF_zvNSHrKazn/category_vehicles/enemyBlue3.png"},"b4878bf5-aba3-4063-9897-b7f4d917859f":{"name":"player","sourceUrl":"assets/api/v1/animation-library/gamelab/Qw5yoM0bthgiqcEVqNRzqtYoXp1Rpzaf/category_vehicles/enemyBlue5.png","frameSize":{"x":97,"y":84},"frameCount":1,"looping":true,"frameDelay":2,"version":"Qw5yoM0bthgiqcEVqNRzqtYoXp1Rpzaf","loadedFromSource":true,"saved":true,"sourceSize":{"x":97,"y":84},"rootRelativePath":"assets/api/v1/animation-library/gamelab/Qw5yoM0bthgiqcEVqNRzqtYoXp1Rpzaf/category_vehicles/enemyBlue5.png"},"1066a37c-88b6-4361-ab0d-0a5321f966fa":{"name":"cave_1","sourceUrl":"assets/api/v1/animation-library/gamelab/noi6SU.ST7VfqHGoH6ijJX1cNwdcFcZM/category_backgrounds/background_cave.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"noi6SU.ST7VfqHGoH6ijJX1cNwdcFcZM","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/noi6SU.ST7VfqHGoH6ijJX1cNwdcFcZM/category_backgrounds/background_cave.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var space= createSprite(0,0,400,400);
space.setAnimation( "space");
space.scale=2.5;
space.y= space.height/2;

var score=0;

var player = createSprite(200,350,10,10);
player.setAnimation( "player");
player.scale=0.6;

var enemy1Group = createGroup();
var enemy2Group = createGroup();
var enemy3Group = createGroup();
var enemy4Group = createGroup();
var shotGroup = createGroup();

function draw(){

  createEdgeSprites();
  player.collide(leftEdge);
  player.collide(rightEdge);
  player.collide(bottomEdge);
  
  player.x = World.mouseX;
    space.velocity=2;
    
  if (space.y > 400) {
    space.y = space.height/2;
  }
    
    if (keyDown("space")) {
    createShot(player.x);
  }
    if (shotGroup.isTouching(enemy1Group)) {
    enemy1Group.destroyEach();
    shotGroup.destroyEach();
    score = score + 1;
  } else if (shotGroup.isTouching(enemy2Group)) {
    enemy2Group.destroyEach();
    shotGroup.destroyEach();
    score = score + 2;
  } else if (shotGroup.isTouching(enemy3Group)) {
    enemy3Group.destroyEach();
    shotGroup.destroyEach(); 
    score = score + 3;
  } else if (shotGroup.isTouching(enemy4Group)) {
    enemy4Group.destroyEach();
    shotGroup.destroyEach();
    score = score + 4;
  }
  
  if (enemy1Group.isTouching(bottomEdge)) {
    score = score - 1;
  }
  
  if (enemy2Group.isTouching(bottomEdge)) {
    score = score -1;
  }
  if (enemy3Group.isTouching(bottomEdge)) {
    score = score -1;
  }
  if (enemy4Group.isTouching(bottomEdge)) {
    score = score -1;
  }
  
  var enemy = randomNumber(0,3);
  
  if (World.frameCount % 50 === 0) {
    if (enemy === 0) {
      createEnemy1();
    } else if (enemy === 1) {
      createEnemy2();
    } else if (enemy === 2) {
      createEnemy3();
    } else {
      createEnemy4();
    }
    if (score>=20||score<30){
      space.setAnimation( "cave_1");
    }
    if(score>30){
      space.setAnimation( "space");
    }
  }
  if (score>6){
    
    
  }
  drawSprites();
   text("Player Score: "+ score,300,40 );
}    
function createEnemy1() {
  var Enemy1 = createSprite(randomNumber(0, 400), 0, 10, 10);
  Enemy1.setAnimation( "enemyBlack3_1");
  Enemy1.velocityY =3;
  Enemy1.lifetime = 1000;
  Enemy1.scale=0.6;
  enemy1Group.add(Enemy1);
}

function createEnemy2() {
  var Enemy2 = createSprite(randomNumber(0, 400), 0, 10, 10);
  Enemy2.setAnimation("enemyGreen3_1");
  Enemy2.velocityY =3;
  Enemy2.lifetime = 1000;
  Enemy2.scale=0.6;
  enemy2Group.add(Enemy2);
}

function createEnemy3() {
  var Enemy3 = createSprite(randomNumber(0, 400), 0, 10, 10);
  Enemy3.setAnimation("enemyRed3_1");
  Enemy3.velocityY =3;
  Enemy3.lifetime = 1000;
  Enemy3.scale=0.6;
  enemy3Group.add(Enemy3);
}

function createEnemy4() {
  var Enemy4 = createSprite(randomNumber(0, 400), 0, 10, 10);
  Enemy4.setAnimation("enemyBlue3_1")        ;
  Enemy4.velocityY =3;
  Enemy4.lifetime = 1000;
  Enemy4.scale=0.6;
  enemy4Group.add(Enemy4);
}

function createShot(x) {
  var Shot= createSprite(100, 100, 5, 10);
  Shot.y = 360;
  Shot.x = x;                                           
  Shot.velocityY = -5;
  Shot.lifetime = 1200;
  shotGroup.add(Shot);
}



// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
